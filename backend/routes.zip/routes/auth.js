const express = require('express');
const router = express.Router();
const User = require('../models/User');
router.get('/', (req, res) => {
  res.send('Auth Route Working');
});

// Register User
router.post('/register', async (req, res) => {
  try {
    const { name, email, password, skills, interests } = req.body;

    const user = new User({
      name,
      email,
      password,
      skills,
      interests,
    });

    await user.save();

    res.status(201).json({
      message: 'User Registered Successfully',
      user,
    });
  } catch (err) {
    res.status(500).json({
      error: err.message,
    });
  }
});

module.exports = router;
